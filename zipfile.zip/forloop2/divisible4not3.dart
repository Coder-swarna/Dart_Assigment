void main(){
   for(int i=20;i<=50;i++){
    if( i%4==3){
      print(i);
    }
   }
}