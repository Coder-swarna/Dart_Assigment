void main(){
  int start=63;
  int end=123;
  while(start<=end){
    if(start%9==0){
   print(start);
    }
     start++;
  } 
}