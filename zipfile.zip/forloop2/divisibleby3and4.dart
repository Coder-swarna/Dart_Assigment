void main(){
   for(int i=1;i<=100;i++){
    if(i%3==0 && i%4==0){
      print(i);
    }
   }
}