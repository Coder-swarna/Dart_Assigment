void main(){
  int start=31;
  int end=55;
  while(start<=end){
    print(start);
    start++;
  }
}