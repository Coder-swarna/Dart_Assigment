void main(){

  int sum=0;
  int square=1;
  
  for(int i=1;i<=15;i++){
    square=i*i;
    sum+=square;
  }

  print(sum);
  
}