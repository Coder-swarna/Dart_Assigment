void main(){
  int ramSize=7;
  if(ramSize<=4){
    print("can't run a code");
  }else if(ramSize>4 && ramSize<=8){
    print("can run a code");
  }else{
    print("invalide runSize");
  }
}