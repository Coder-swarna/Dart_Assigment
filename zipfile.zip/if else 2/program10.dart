void main(){
  dynamic per=90;
  dynamic cgpa=8.90;
  if(per>=70.0 && cgpa>=7.0){
    print("you are eligible");
  }else{
    print("you are not eligible");
  }
}