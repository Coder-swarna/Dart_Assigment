void main(){
  String colour="4";

  switch(colour){

    case "1":
    print("violet");

    case "2":
    print("indigo");

    case "3":
    print("blue");

    case "4":
    print("green");

    case "5":
    print("yellow");

    case "6":
    print("orange");

    case "7":
    print("red");

    default:
    print("invalid case");
  }
}