void main(){
  int x=40;

  if(x>=30 && x<=50){
    print("number is in correct range");
  }else{
    print("invalid number");
  }
}