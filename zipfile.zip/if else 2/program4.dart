void main(){
  int x=20;
  if(x>=16 && x%2==0){
    print("valid number");
  }else{
    print("invalid number");
  }
}