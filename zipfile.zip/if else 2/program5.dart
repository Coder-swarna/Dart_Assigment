    void main(){
      int x=16;
      if(x/3==2 || x/3<=2){
        print("remainder is equal to 2");
      }else{
        print("remainder is less than 2");
      }
    }