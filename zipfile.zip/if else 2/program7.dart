void main(){
  int noOfPerson=16;
  if(noOfPerson>=8){
    print("you can't enter in lift");
  }else{
    print("you can enter in lift");
  }
}