void main(){
  String vehicle="scooter";
  if(vehicle=="bike"){
    print("go to parking2");
  }else if(vehicle=="scooter"){
    print("go to parking1");
  }else{
    print("no parking");
  }
}