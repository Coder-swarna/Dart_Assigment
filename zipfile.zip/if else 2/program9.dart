void main(){
  int num=15;
  if(num>=0 && num<=25){
    print("grade D");
  }else if(num>25 && num<=50){
    print("grade C");
  }else if(num>50 && num<=75){
    print("grade B");
  }else if(num>75 && num<=100){
    print("grade A");
  }else{
    print("not possible");
 }
   }
