void main(){
  var x=6;
  if(x%2==0){
    print("x is an even number ");
  }else{
    print("x is an odd number");
      }
}