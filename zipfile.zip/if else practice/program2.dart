   void main(){
    var x=5;
    if(x<10){
      print("less thna 10:");
    }else {
      print("greater than 10:");
    }
   }