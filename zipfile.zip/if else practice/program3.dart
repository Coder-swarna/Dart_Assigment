void main(){
int age=5;
if(age>=18){
  print("you can cast a vote");
}else{
  print("you can not cast a vote");
}
}