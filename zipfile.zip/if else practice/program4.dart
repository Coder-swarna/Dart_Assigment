void main(){
  dynamic x=5;
  if(x<0){
    print("$x a negative value ");
  }else if(x>0){
    print("$x a positive value");
  }else{
    print("it is neither positive nor positive");
  }
}