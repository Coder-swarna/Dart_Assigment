void main(){
  var c="A";
  if(c=="A" || c=="a"){
    print("$c is vowel");
  }else if(c=="E" || c=="e"){
    print("$c is vowel");
  }else if(c=="I" || c=="i"){
    print("$c is vowel");
  }else if(c=="O" || c=="o"){
    print("$c is vowel");
  }else if(c=="U" || c=="u"){
    print("$c is vowel");
  }else{
    print("it is a consonant");
  }
}