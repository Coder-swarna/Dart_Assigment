void main(){
  var x=8;
  if(x==1){
    print("one");
  }else if(x==2){
    print("two");
  }else if(x==3){
    print("three");
  }else if(x==4){
    print("four");
  }else if(x==5){
    print("five");
  }else{
    print("no is greater than 5");
  }
}