void main(){
  int month=6;
  switch(month){
    case 1:
    print("jan has 31 days");
    case 2:
    print("feb has 28 days");
    case 3:
    print("mar has 31 days");
    case 4:
    print("april has 30 days");
    case 5:
    print("may has 31 days");
    case 6:
    print("june has 30 days");
    case 7:
    print("july has 31 days");
    case 8:
    print("aug has 31 days");
    case 9:
    print("sep has 30 days");
    case 10:
    print("oct has 31 days");
    case 11:
    print("nov has 30 days");
    case 12:
    print("dec has 31 days");
    default:
    print("invliad month");
  }
}