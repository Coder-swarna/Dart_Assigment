void main(){
  int x=4;
  switch(x){
    case 1:
    print("price is 2000");
    case 2:
    print("price is 3000");
    case 3:
    print("price is 7000");
   default:
    print("price is 2500");
  
  }
}