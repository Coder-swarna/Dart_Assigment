void main(){
  int start=50;
  int end=40;
  while(start>=end){
    if(start%2==0){
      print(start*start);
    }
    start--;
  }
}