
import"dart:core";

void main(){
  int start=30;
  int end=50;
  while(start<=end){
    if(end%2==0){
      print(end);
      print(" ");
    }
    end--;
  }
}