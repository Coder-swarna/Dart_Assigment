void main(){
  int num=5;
  int i=10;
  while(i>=1){
    print(i*num);
    i--;
  }
}