void main(){
  int i=9;
  while(i>0){
    print(i);
    i--;
  }
}