void main(){
    int start=10;
    int end=20;

    while(start<=end){
        if(start%2==1){
            print(start*start);
        }
        start++;
    }
}